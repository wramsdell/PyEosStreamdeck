from SdPlus import sdPlus
from PIL import Image, ImageSequence, ImageDraw, ImageFont
from StreamDeck.DeviceManager import DeviceManager
from StreamDeck.ImageHelpers import PILHelper
from StreamDeck.Transport.Transport import TransportError

def drawLcdBackground(img):
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle(((10, 10), (190, 90)), 10, fill="blue", outline="white", width=3)
    draw.rounded_rectangle(((210, 10), (390, 90)), 10, fill="blue", outline="white", width=3)
    draw.rounded_rectangle(((410, 10), (590, 90)), 10, fill="blue", outline="white", width=3)
    draw.rounded_rectangle(((610, 10), (790, 90)), 10, fill="blue", outline="white", width=3)
    return img

def drawLcdText(index, text, font, img):
    d = ImageDraw.Draw(img)
    d.multiline_text(((index*200)+20, 33), text, font=font, fill="white")
    return img

def drawKeyBackground(img):
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle(((10, 10), (110, 110)), 20, fill="blue", outline="white", width=3)
    return img

sd = sdPlus()

font = ImageFont.truetype("APTOS.TTF", 26, encoding="unic")
img = Image.new('RGB', (800, 100), 'black')
img = drawLcdBackground(img)
img = drawLcdText(0, "foobar", font, img)

for i in range(8): sd.setKeyImage(i,drawKeyBackground(Image.new('RGB', (120, 120), 'black')))
sd.setLcdImage(img)

while True:
    continue


# import itertools
# import os
# import threading
# import time
# import io
# import PIL

# from fractions import Fraction
# from PIL import Image, ImageSequence, ImageDraw, ImageFont
# from StreamDeck.DeviceManager import DeviceManager
# from StreamDeck.ImageHelpers import PILHelper
# from StreamDeck.Transport.Transport import TransportError

# FRAMES_PER_SECOND=30

# font = ImageFont.truetype("ALGER.TTF", 26, encoding="unic")
# lcdImg = Image.new('RGB', (800, 100), 'black')
# lcdIndices=[0,0,0,0]

# def drawLcdBackground():
#     draw = ImageDraw.Draw(lcdImg)
#     draw.rounded_rectangle(((10, 10), (190, 90)), 10, fill="blue", outline="white", width=3)
#     draw.rounded_rectangle(((210, 10), (390, 90)), 10, fill="blue", outline="white", width=3)
#     draw.rounded_rectangle(((410, 10), (590, 90)), 10, fill="blue", outline="white", width=3)
#     draw.rounded_rectangle(((610, 10), (790, 90)), 10, fill="blue", outline="white", width=3)

# def drawLcdText(index,text):
#     d = ImageDraw.Draw(lcdImg)
#     d.multiline_text(((index*200)+20, 26), text, font=font, fill="white")

# def setLcdImg():
#     img_byte_arr = io.BytesIO()
#     lcdImg.save(img_byte_arr, format='JPEG')
#     img_byte_arr = img_byte_arr.getvalue()
#     deck.set_lcd_image(0, 0, 800, 100, img_byte_arr)

# def keyChange(deck, key, keyState):
#     print("Key change")

# def rotaryChange(deck, rotary, rotary_state):
#     print("Rotary change")

# def rotaryTurned(values):
# #        print("Rotary turned")
#     i=0
#     for v in values:
#         if v>0:
#             lcdIndices[i]+=v
#             t1=lcdIndices[index]
#             t2=lcdIndices[index]+1
#             animateIncrement(index,t1,t2,1,2)
#             lcdIndices[index]+=1            
#         i+=1

# def lcdTouched(event_type, x, y, x_out = 0, y_out = 0):
#     print("LCD touched")
#     index=int(x/200)
#     t1=lcdIndices[index]
#     t2=lcdIndices[index]+1
#     animateIncrement(index,t1,t2,1,2)
#     lcdIndices[index]+=1

# def animateIncrement(index,text1,text2,direction,speed):
#     t0=time.time()
#     numFrames=speed*FRAMES_PER_SECOND
#     for i in range(numFrames):/
#         tFrame=t0+(i*(1/FRAMES_PER_SECOND))
#         while(time.time()<tFrame):
#             continue
#         frame=lcdImg
#         draw = ImageDraw.Draw(frame)
#         draw.rounded_rectangle(((10+(index*200), 10), (190+(index*200), 90)), 10, fill="blue", outline="white", width=3)
#         y1=round(i/numFrames*26)
#         y2=26+round(i/numFrames*26)
#         draw.multiline_text(((index*200)+20, y1), text1, font=font, fill="white")
#         draw.multiline_text(((index*200)+20, y2), text2, font=font, fill="white")
#         img_byte_arr = io.BytesIO()
#         frame.save(img_byte_arr, format='JPEG')
#         img_byte_arr = img_byte_arr.getvalue()
#         deck.set_lcd_image(0, 0, 800, 100, img_byte_arr)
#     lcdImg=frame


# streamdecks = DeviceManager().enumerate()

# print("Found {} Stream Deck(s).\n".format(len(streamdecks)))

# deck=None

# for index, d in enumerate(streamdecks):
#     if d.DECK_TYPE == 'Stream Deck +': deck = d

# if deck == None: quit()

# deck.open()
# deck.reset()

# deck.set_key_callback(keyChange)
# deck.set_rotarypush_callback(rotaryChange)
# deck.set_rotaryturn_callback(rotaryTurned)
# deck.set_lcdtouch_callback(lcdTouched)

# deck.set_brightness(100)
# drawLcdBackground()
# drawLcdText(0,"Hello Angie")
# setLcdImg()
# while True:
#     continue