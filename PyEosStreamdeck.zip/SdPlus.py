import itertools
import os
import threading
import time
import io
import PIL
import math

from fractions import Fraction
from PIL import Image, ImageSequence, ImageDraw, ImageFont
from StreamDeck.DeviceManager import DeviceManager
from StreamDeck.ImageHelpers import PILHelper
from StreamDeck.Transport.Transport import TransportError
FRAMES_PER_SECOND=30

class sdPlus:
    def __init__(self):
        print("Init!")
        streamdecks = DeviceManager().enumerate()

        print("Found {} Stream Deck(s).\n".format(len(streamdecks)))

        self.deck=None

        for index, d in enumerate(streamdecks):
            if d.DECK_TYPE == 'Stream Deck +': self.deck = d

        if self.deck == None: return

        self.deck.open()
        self.deck.reset()

        self.deck.set_key_callback(self.keyChange)
        self.deck.set_rotarypush_callback(self.rotaryChange)
        self.deck.set_rotaryturn_callback(self.rotaryTurned)
        self.deck.set_lcdtouch_callback(self.lcdTouched)

        self.deck.set_brightness(100)

    
    def keyChange(self, deck, key, keyState):
        print("Key change")
        print(key)
        print(keyState)

    def rotaryChange(self, deck, rotary, rotaryState):
        print("Rotary change")
        print(rotary)
        print(rotaryState)

    def rotaryTurned(self, values):
        print("Rotary turned")
        print(values)

    def lcdTouched(self, event_type, x, y, xOut = 0, yOut = 0):
        x=int(x)
        y=int(y)
        xOut=int(xOut)
        yOut=int(yOut)
        if event_type == self.deck.TOUCH_EVENT_SHORT:
            print(f"LCD short-touched at {x},{y}")
        if event_type == self.deck.TOUCH_EVENT_LONG:
            print(f"LCD long-touched at {x},{y}")
        if event_type == self.deck.TOUCH_EVENT_DRAG:
            print(f"LCD dragged from {x},{y} to {xOut},{yOut}")
            if (abs(x-xOut)>abs(y-yOut)):
                if x>xOut: print("Left Swipe")
                else: print("Right swipe")
            if (abs(x-xOut)<abs(y-yOut)):
                if y>yOut: print("Up Swipe")
                else: print("Down swipe")
   
    def setKeyCallback(self, func):
        self.deck.set_key_callback(func)

    def setRotaryPushCallback(self, func):
        self.deck.set_rotarypush_callback(func)

    def setRotaryTurnCallback(self, func):
        self.deck.set_rotaryturn_callback(func)

    def setLcdTouchCallback(self, func):
        self.deck.set_lcdtouch_callback(func)
    
    def setKeyImage(self, key, img):
        img_byte_arr = io.BytesIO()
        img.save(img_byte_arr, format='JPEG')
        img_byte_arr = img_byte_arr.getvalue()

        self.deck.set_key_image(key, img_byte_arr)

    def setLcdImage(self, img, xPos=0, yPos=0, width=800, height=100):
        self.lcdImg = img
        img_byte_arr = io.BytesIO()
        self.lcdImg.save(img_byte_arr, format='JPEG')
        img_byte_arr = img_byte_arr.getvalue()

        self.deck.set_lcd_image(xPos, yPos, width, height, img_byte_arr)

    def __del__(self):
        self.deck.close()